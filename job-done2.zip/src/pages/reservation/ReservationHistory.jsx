import Estimate from "../../components/papers/Estimate";
function ReservationHistory() {
  return (
    <div>
      예약내역페이지
      {/* 견적서 임시 컴포넌트 확인용*/}
      <Estimate />
    </div>
  );
}

export default ReservationHistory;
