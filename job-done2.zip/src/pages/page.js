import styled from "@emotion/styled";

// 레이아웃(임시)
export const LayoutDiv = styled.div`
  max-width: 1280px;
  margin: 0 auto;
`;
