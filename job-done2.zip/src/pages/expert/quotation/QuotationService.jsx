import React from "react";

function QuotationService() {
  return <div>QuotationService</div>;
}

export default QuotationService;
