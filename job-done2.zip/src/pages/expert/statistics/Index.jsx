import React from "react";

function Index() {
  return <div>통계페이지</div>;
}

export default Index;
