import React from "react";

function ExpertDetailPage() {
  return <div>ExpertDetailPage</div>;
}

export default ExpertDetailPage;
