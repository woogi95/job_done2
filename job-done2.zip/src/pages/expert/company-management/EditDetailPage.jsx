import React from "react";

function EditDetailPage() {
  return <div>EditDetailPage</div>;
}

export default EditDetailPage;
