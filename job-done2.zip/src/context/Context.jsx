import React from "react";

const Context = () => {
  return <div>Context</div>;
};

export default Context;
