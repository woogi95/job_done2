import { atom } from "recoil";
// 기업 정보 폼
export const statusAtom = atom({
  key: "statusAtom",
  default: 0,
});
